# INFOGRAM
## PROYECTO DE APLICACION PARA DISPOSITIVOS MOVILES


Se desarrolla una aplicacion movil que permita mostrar imagenes con una breve descripcion de cada una.

## APLICACIONES UTILIZADAS
>Android Studio





